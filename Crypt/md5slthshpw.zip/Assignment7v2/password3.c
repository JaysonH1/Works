#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <stddef.h>
#include <openssl/md5.h>
int md5summer(char* word,char* hash)
{
    unsigned char c[MD5_DIGEST_LENGTH];
    MD5_CTX mdContext;
    MD5_Init (&mdContext);
    MD5_Update (&mdContext, word, strlen(word));
    MD5_Final (c,&mdContext);
    int i;
    for(i = 0; i < MD5_DIGEST_LENGTH; i++) 
		sprintf(hash+2*i,"%02x", c[i]);

    return 0;
}
void get_salt_string(char *s,int saltlen)
{
int devrnd = open("/dev/random", O_RDONLY);
assert(devrnd != -1);
int numbytesread = 0;
char buf[100];
while(numbytesread < saltlen)
{
numbytesread += read(devrnd,buf+numbytesread,saltlen);
}
int i;
for(i = 0; i < saltlen; i++)
    {
sprintf(s+2*i,"%02x", buf[i]);
s[2*saltlen] = '\0';
}
close(devrnd);
}



int main(){

    char sign[1]="$";
     FILE* fp = fopen("digested.txt","w");

    char digest[2*MD5_DIGEST_LENGTH+1];

    char strin[30]="xx";
    int saltlen;
        saltlen=2*strlen(strin);
    char pass[50]="";
    printf("Enter password \n");
    scanf("%49s",pass);
    get_salt_string(strin,saltlen);
fputc(sign[0],fp);
int i;
    printf("Your salt is ");
    for(i=0;i<8;i++)
    printf("%c",strin[i]);
    printf("\n");
    int y=0;
    while(y<8)
	{
		fputc(strin[y++],fp);
	}
    fputc(sign[0],fp);
    char str[150];

    
    for(i=0;i<30;i++)
    {
        str[i]=strin[i];
    }
    
    
    
    
    strcat(str, pass);
   
    printf("salt and pw is ");
    printf("%s",str);
    printf("\n");
   
    
    md5summer(str,digest);
    
    y=0;
  while(y<2*MD5_DIGEST_LENGTH+1)
	{
		fputc(digest[y++],fp);
	}
	fclose(fp);
        
   printf("The md5sum of \"%s\" is: \n%s\n",str,digest);
    
    printf("your retrieved salt and hash from the file is ");
    
   
    
    FILE *fp2 = fopen("digested.txt", "rb");
    int rv = 0;
    if (fp != 0)
    {
        char line[50];
        if (fgets(line, sizeof(line), fp) != 0)
            rv = atoi(line);

         for(i=0;i<40;i++)
    printf("%c",line[i]);           
        fclose(fp2);
    }

}