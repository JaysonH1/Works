#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <stddef.h>
#include <openssl/md5.h>






int md5summer(char* word,char* hash)
{
    unsigned char c[MD5_DIGEST_LENGTH];
    MD5_CTX mdContext;
    MD5_Init (&mdContext);
    MD5_Update (&mdContext, word, strlen(word));
    MD5_Final (c,&mdContext);
    int i;
    for(i = 0; i < MD5_DIGEST_LENGTH; i++) 
		sprintf(hash+2*i,"%02x", c[i]);

    return 0;
}




void get_salt_string(char *s,int saltlen)
{
int devrnd = open("/dev/random", O_RDONLY);
assert(devrnd != -1);
int numbytesread = 0;
char buf[100];
while(numbytesread < saltlen)
{
numbytesread += read(devrnd,buf+numbytesread,saltlen);
}
int i;
for(i = 0; i < saltlen; i++)
    {
sprintf(s+2*i,"%02x", buf[i]);
s[2*saltlen] = '\0';
}
    //printf("%2x",buf[0]);
//sprintf(s+2*i,"%02x", buf[1]);
close(devrnd);
}



int main(){
    
     char digest[2*MD5_DIGEST_LENGTH+1];
   
    char salt[8];
    int i;
    char line[50];
    char hash[50];
    char pass[50]="xxxxxxxxxxxxxxxxxxxxxxxxxxxx";
    printf("Enter password \n");
    scanf("%49s",pass);
    
    
    
    
    
    FILE *fp2 = fopen("shaddy.txt", "rb"); //gets content of shaddy and puts in char line
    int rv = 0;
    if (fp2 != 0)
    {
       
        
        if (fgets(line, sizeof(line), fp2) != 0)
            rv = atoi(line);

    }
    
    salt[0]=line[1];
    for(i=1;i<8;i++){
     salt[i]=line[i+1];
        // printf("%c",line[i]);
  }
    salt[8]='\0';
    
    
   printf("your retrieved salt is ");
   
    for(i=0;i<8;i++)
    {
     
         printf("%c",salt[i]);
    
     }
    
    
    
    printf("\n");
     printf("your retrieved hash is ");
    
    int hc=0;
            for(i=10;i<=41;i++)
            {
     
         hash[hc]=line[i];
        printf("%c",hash[hc]);
        hc++;
             }
    
        hash[32]=line[42];
    
        printf("\n");
     
    strcat(salt, pass);
    printf("your salt and password is ");
    printf("%s",salt); //not just salt, concat with pw
    
   
    md5summer(salt,digest);
    printf("\n");
    printf("The md5sum of \"%s\" is: \n%s\n",salt,digest);

    digest[32]='\0';
    printf("\n");
    hash[32]='\0';

    
    int counter=0;
    
    
    for (i=0;i<30;i++)
    if (hash[i]==digest[i])
    {
        counter++;
    }
    
      
       
    
    
    if(counter==30){
    
        printf("ACCESS GRANTED");
    }
    else
        printf("ACCESS DENIDED");
    fclose(fp2);



    



}